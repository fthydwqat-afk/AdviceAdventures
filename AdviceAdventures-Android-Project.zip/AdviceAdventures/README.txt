Advice Adventures - Android WebView project
Build: gradle assembleDebug  (JDK 17, Android SDK 34)
APK: app/build/outputs/apk/debug/app-debug.apk
The game is app/src/main/assets/index.html (unchanged copy).
